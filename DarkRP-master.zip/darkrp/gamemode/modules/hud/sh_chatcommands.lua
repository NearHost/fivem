DarkRP.declareChatCommand{
    command = "admintell",
    description = "Send a private, very intimidating message to someone.",
    delay = 1.5,
    tableArgs = true
}

DarkRP.declareChatCommand{
    command = "admintellall",
    description = "Send a very intimidating message to everyone.",
    delay = 1.5
}

GM.NoLicense["weapon_physcannon"] = true
GM.NoLicense["weapon_physgun"] = true
GM.NoLicense["weapon_bugbait"] = true
GM.NoLicense["gmod_tool"] = true
GM.NoLicense["gmod_camera"] = true
